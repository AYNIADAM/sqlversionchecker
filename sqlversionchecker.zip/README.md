# SQL DATA Version Checker

## English Description

Modern, multi-language desktop app for batch SQL Server MDF, BAK, and BCK file version detection and health check.

This application is designed for IT professionals and database administrators who need to quickly and reliably identify the version and integrity of large numbers of SQL Server data and backup files. It not only finds all relevant files in the selected folder and its subfolders, but also tests each file, detects its SQL Server version, and distinguishes between healthy and corrupted files. Results can be filtered, and batch actions can be performed for efficient management.

### Features
- Scans selected folder and all subfolders to find every `.mdf`, `.bak`, and `.bck` file
- Tests each file to detect its SQL Server version and checks file health (healthy/corrupted)
- Clearly separates and marks healthy and corrupted files in the results
- Batch version checking and result filtering (by status, file type, etc.)
- Modern dashboard UI with SVG/PNG icons
- Batch move and delete operations (preserves original folder structure, prevents overwriting)
- CPU/RAM friendly, stable operation with progress bar and responsive interface
- Multi-language support (Turkish/English, flag selector at top right)
- Result filtering, batch select, and progress tracking for large datasets

### Installation
```bash
pip install -r requirements.txt
```

### Usage
```bash
python main.py
```

### Contribution & License
Open source under MIT license. Contributions welcome!

---

## Türkçe Açıklama

SQL Server MDF, BAK ve BCK dosyalarının sürümünü ve bütünlüğünü toplu ve hızlı şekilde tespit eden, modern ve çok dilli (Türkçe/İngilizce) bir masaüstü uygulamasıdır.

Bu uygulama, çok sayıda SQL Server veri ve yedek dosyasının sürümünü ve sağlığını hızlıca tespit etmek isteyen IT uzmanları ve veritabanı yöneticileri için geliştirilmiştir. Sadece klasör ve alt klasörlerdeki ilgili dosyaları bulmakla kalmaz, her bir dosyayı test eder, SQL Server sürümünü belirler ve dosyanın sağlıklı mı yoksa bozuk mu olduğunu ayırt eder. Sonuçlar filtrelenebilir ve toplu işlemlerle dosya yönetimi kolaylaştırılır.

### Özellikler
- Seçilen klasör ve tüm alt klasörlerdeki `.mdf`, `.bak`, `.bck` dosyalarını bulur
- Her dosyayı test ederek SQL Server sürümünü ve dosya bütünlüğünü (sağlam/bozuk) tespit eder
- Sağlam ve bozuk dosyaları sonuçlarda açıkça ayırır ve işaretler
- Toplu sürüm kontrolü ve sonuç filtreleme (duruma, dosya tipine göre vb.)
- Modern dashboard arayüzü, SVG/PNG ikonlar
- Toplu taşıma ve silme işlemleri (orijinal dizin yapısı korunur, dosya üzerine yazma engellenir)
- CPU/RAM dostu, stabil çalışma; ilerleme çubuğu ve duyarlı arayüz
- Çoklu dil desteği (Türkçe/İngilizce, sağ üstte bayrak ile seçim)
- Sonuçları filtreleme, toplu seçim ve büyük veri kümeleri için ilerleme takibi

### Kurulum
```bash
pip install -r requirements.txt
```

### Kullanım
```bash
python main.py
```

### Katkı ve Lisans
MIT lisansı ile açık kaynak. Katkılarınızı bekleriz!

---

## Author / Yazar
- **Author** AYNIADAM
- **E-mail:** a.ceyhan@goldverikurtarma.com
- **Web:** [www.goldverikurtarma.com](https://www.goldverikurtarma.com) 
